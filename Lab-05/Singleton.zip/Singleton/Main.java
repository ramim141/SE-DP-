public class Main {
    public static void main(String[] args) {
        Hasina h1 = Hasina.getHasina();
        // Hasina h2 = Hasina.getHasina();
        // Hasina h3 = Hasina.getHasina();

        // System.out.println(h1);
        // System.out.println(h2);
        // System.out.println(h3);

        //Khaleda k1 = Khaleda.getKhaleda();
    }
}
